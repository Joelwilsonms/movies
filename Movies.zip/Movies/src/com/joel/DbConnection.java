package com.joel;
import java.sql.Connection;
import java.sql.DriverManager;
public class DbConnection {
	public static Connection getConnection()
	{
		String className="com.mysql.jdbc.Driver";
		String url="jdbc:mysql://localhost:3306/movies";
		String username="root";
		String password="root";
		Connection con=null;
		if(con==null)
		{
			try 
			{
				Class.forName(className);
				con=DriverManager.getConnection(url, username, password);
			} 
			catch (Exception e)
			{
				System.out.println(e);
				e.printStackTrace();
			}
			
		}
		return con;
		
		
	}
	
}