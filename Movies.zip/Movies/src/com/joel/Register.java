package com.joel;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Register extends HttpServlet
{
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		resp.setContentType("text/html");
		
		PrintWriter pw=resp.getWriter();
		
		String movie_name=req.getParameter("movie_name");
		String actor=req.getParameter("actor");
		String actress=req.getParameter("actress");
		String Year_of_release=req.getParameter("Year_of_release");
		String director_name=req.getParameter("director_name");
		
		Connection con=null;
		PreparedStatement ps=null;
		
		String insertQuery="insert into movie values(?,?,?,?,?)";
		
		try 
		{
			
			con=DbConnection.getConnection();
			ps=con.prepareStatement(insertQuery);
			
			ps.setString(1,movie_name);
			ps.setString(2,actor);
			ps.setString(3,actress);
			ps.setString(4,Year_of_release);
			ps.setString(5,director_name);
			
			int result=ps.executeUpdate();
			if(result==1)
			{
				pw.println("<h2 style='text-align:center;color:green'>Congratulations "+movie_name+" is successfully Registered "+" . <a href='home.html'>Search</a></h2>");
			}
			else
			{
				pw.println("<h2 style='text-align:center;color:red'>Sorry , Something Went Wrong .Please Try Again after sometime</h2>");
			}
		} 
		catch (Exception e) {
			
			System.out.println(e);
		}
		
		
	}

}
