package com.joel;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Login extends HttpServlet
{
LocalDateTime ldt = LocalDateTime.now();
	@Override
		public void init() throws ServletException {
		LocalDateTime ldt = LocalDateTime.now();
		System.out.println("Init() method executed at "+ ldt);
		}

	@Override
	public void destroy() {
		LocalDateTime ldt = LocalDateTime.now();
		System.out.println("Destroy() method executed at " + ldt);
	}
protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException,
IOException
{
	LocalDateTime ldt = LocalDateTime.now();
	System.out.println("Service() method executed at "+ ldt);
	Connection con=null;
	PreparedStatement ps=null;
	ResultSet rs=null;	
	String selectQuery="select movie_name from movie where actor=?";
	
	resp.setContentType("text/html");
	PrintWriter pw=resp.getWriter();
	
	String actor=req.getParameter("actor");
	String actress=req.getParameter("actress");


	

	try 
	{
	con=DbConnection.getConnection();
	System.out.println(con);
	ps=con.prepareStatement(selectQuery);
	ps.setString(1,actor);


	rs=ps.executeQuery();
	
	if(rs.next())
	{
		String username=rs.getString(1);
		pw.println("<h2 style='color:green;text-align:center'>Movie Search Success , "+ "Movie Name "+username+"</h2>");
		pw.println("<h4 style='text-align:right'><a href='home.html'>Search</a></h4>");
	}
	else
	{
		pw.println("<h2 style='color:red;text-align:center'>Invalid Movie , <a href='home.html'>Try Again</a></h2>");
	}
	
	} 
	catch (SQLException e)
	{
		e.printStackTrace();
	}
	
	try {
		con.close();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	pw.println("<h2>Your Movie Actor :"+actor+"</h2>");



	
}
}
